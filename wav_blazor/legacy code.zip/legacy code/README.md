# web-activity-visualization
a JavaScript plugin and server application to graphically show how much time a user spent on different parts of a webpage
